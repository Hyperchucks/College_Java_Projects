/***********************************************************************
 * Program Name: Client.java 
 * Programmer's Name: 
 * Program Description: This class represent a client
 ***********************************************************************/
public class Client {

	private String name;
	private String id;
	private String startingBal;
	private String endingBal;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStartingBal() {
		return startingBal;
	}

	public void setStartingBal(String startingBal) {
		this.startingBal = startingBal;
	}

	public String getEndingBal() {
		return endingBal;
	}

	public void setEndingBal(String endingBal) {
		this.endingBal = endingBal;
	}
}
