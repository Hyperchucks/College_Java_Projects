import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author muhoilya
 */
public class ClientReader extends JFrame implements ActionListener {

	ArrayList<Client> clients = new ArrayList<>(); // list of clients
    JTextField fileNameText; //text field
    JButton displayButton = new JButton("Display"); // display button 
    JPanel upperPanel = new JPanel();
    JPanel lowerPanel = new JPanel();

    // default constructor
    ClientReader() {
        super("Client Information");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addComponentsToPane(getContentPane());
        setSize(300, 300);
        pack();
        setVisible(true);
    }

    // Create GUI
    public final void addComponentsToPane(Container contentPane) {
        
    	// set the panel layout
    	contentPane.add(upperPanel, "North");
        contentPane.add(lowerPanel, "East");
        upperPanel.setLayout(new GridLayout(0, 1));
        lowerPanel.setLayout(new FlowLayout());

		// Add read form label and text field on the form
        upperPanel.add(new JLabel("File to Read From: "));
        fileNameText = new JTextField(25);
        upperPanel.add(fileNameText);

		// Add display button on the form
        lowerPanel.add(displayButton);
        displayButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    	// Read from file and display it in console 
        try {
            File file = new File("client.txt"); // file to read
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            try {
                String s;
                // Print header
                System.out.println(br.readLine());
                System.out.println(br.readLine());
                
                // add clients to the list
                while ((s = br.readLine()) != null) {
                    Client c = new Client();

                    c.setName(s.substring(0, 20));
                    c.setId(s.substring(20, 35));
                    c.setStartingBal(s.substring(35, 55));
                    c.setEndingBal(s.substring(55, 75));

                    clients.add(c);
                }
            } finally {
                br.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // Display clients in the console 
        for (Client client : clients) {
            System.out.format("%-20s%-15s%-20s%-20s", client.getName(), client.getId(), client.getStartingBal(), client.getEndingBal());
            System.out.println();
        }

        System.out.println();
    }

    public static void main(String[] args) {
        ClientReader cr = new ClientReader();
    }
}
