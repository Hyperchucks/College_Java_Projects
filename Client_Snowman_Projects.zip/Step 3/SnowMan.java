import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;

/***********************************************************************
 * Program Name: SnowMan.java 
 * Programmer's Name: 
 * Program Description: This program draw a snowman
 ***********************************************************************/
public class SnowMan extends javax.swing.JFrame {

	SnowMan() {
		super("Snow Man");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300, 300);
		setBackground(Color.blue);
		setVisible(true);
	}

	@Override
	public void paint(Graphics frame) {
		super.paint(frame);

		final int X = 150; // middle point of the snowman
		final int Y = 50; // top point of the snowman

		// set the background
		frame.setColor(Color.blue);
		frame.fillRect(0, 0, 500, 300);

		// draw snowman body
		frame.setColor(Color.white);
		frame.fillOval(X - 30, Y, 50, 50);
		frame.fillOval(X - 45, Y + 45, 80, 60);
		frame.fillOval(X - 60, Y + 100, 110, 80);

		// draw eyes
		frame.setColor(Color.green);
		frame.fillRect(X - 20, Y + 10, 7, 7);
		frame.fillRect(X + 5, Y + 10, 7, 7);

		// draw nose
		frame.setColor(Color.yellow);
		frame.fillOval(X - 8, Y + 20, 8, 8);

		// draw mouth
		frame.setColor(Color.black);
		frame.drawLine(X - 15, Y + 35, X + 5, Y + 35);

		frame.drawString("My Snowman!", X - 40, Y + 200);

	}

	public static void main(String[] args) {
		SnowMan sm = new SnowMan();
	}

}
