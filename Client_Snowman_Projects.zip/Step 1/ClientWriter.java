import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/***********************************************************************
 * Program Name: ClientWriter.java 
 * Programmer's Name: 
 * Program Description: This program Write Client Information on file
 ***********************************************************************/
public class ClientWriter extends JFrame implements ActionListener {

	JTextField nameText, idText, startingBalText, endingBalText; // text fields
	JButton saveButton = new JButton("Save"); // save button
	JPanel upperPanel = new JPanel();
	JPanel lowerPanel = new JPanel();

	// Default constructor
	ClientWriter() {
		super("Client Information");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addComponentsToPane(getContentPane());
		setSize(300, 300);
		pack();
		setVisible(true);
	}

	// Set the layout of the form
	public void addComponentsToPane(Container contentPane) {

		contentPane.add(upperPanel, "North");
		contentPane.add(lowerPanel, "East");
		upperPanel.setLayout(new GridLayout(0, 4));
		lowerPanel.setLayout(new FlowLayout());

		// Add client name label and text field on the form
		upperPanel.add(new JLabel("Client Name: "));
		nameText = new JTextField(12);
		upperPanel.add(nameText);

		// Add client id label and text field on the form
		upperPanel.add(new JLabel("Client ID: "));
		idText = new JTextField(12);
		upperPanel.add(idText);

		// Add starting balance label and text field on the form
		upperPanel.add(new JLabel("Starting Balance: "));
		startingBalText = new JTextField(12);
		upperPanel.add(startingBalText);
		
		// Add closing balance label and text field on the form
		upperPanel.add(new JLabel("Closing Balance: "));
		endingBalText = new JTextField(12);
		upperPanel.add(endingBalText);

		// Add save button on the form
		lowerPanel.add(saveButton);
		saveButton.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		// Header row with format
		String header = String.format("%-20s%-15s%-20s%-20s", "Client Name",
				"Client ID", "Starting Balance", "Ending Balance");

		// get the input from user to be saved
		String clientDetails = String.format("%-20s%-15s%-20s%-20s",
				nameText.getText(), idText.getText(),
				startingBalText.getText(), endingBalText.getText());

		// file to be used
		File file = new File("client.txt");

		// if file doesn't exists, then create it and add header
		if (!file.exists()) {
			try {
				file.createNewFile();
				try (PrintWriter out = new PrintWriter(new BufferedWriter(
						new FileWriter(file.getName(), true)))) {
					out.println("\t \t \t Client Activity Report");
					out.println(header);
				}
			} catch (IOException ex) {
				System.out.println("unable to create file");
			}
		}

		// Add client details in the file
		try (PrintWriter out = new PrintWriter(new BufferedWriter(
				new FileWriter("client.txt", true)))) {
			out.println(clientDetails);
			JOptionPane.showMessageDialog(null, "Client Details added");
		} catch (IOException ex) {

		}
	}

	public static void main(String[] args) {
		ClientWriter cw = new ClientWriter();
	}
}
